package ues21.ejerciciosfeedback.ues21ejercicofeedback1;

public interface TravelItemsInterface {

	public final static String NAME = "NAME";
	public final static String YEAR = "YEAR";
	public final static String COUNTRY = "COUNTRY";
	public final static String COMMENTS = "COMMENTS";
	public static final String ITEM_ID = "ITEM_ID";
	
}
