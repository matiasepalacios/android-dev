package ues21.ejerciciosfeedback.ues21ejercicofeedback1;

import android.app.Activity;
import android.os.Bundle;

public class TravelActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_travel);
	}
}
