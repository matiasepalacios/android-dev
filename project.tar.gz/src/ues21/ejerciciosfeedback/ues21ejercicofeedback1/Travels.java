package ues21.ejerciciosfeedback.ues21ejercicofeedback1;

import android.provider.BaseColumns;

public class Travels implements BaseColumns {

	public static final String NAME = "name";
	
	public static final String COUNTRY = "country";
	
	public static final String YEAR = "year";
	
	public static final String COMMENTS = "comments";
	

}
